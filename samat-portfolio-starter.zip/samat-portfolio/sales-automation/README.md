# Automated Sales Reporting

**Goal:** ETL from CRM → clean in Python → Excel dashboards.

## Run
```bash
python sales_reporting.py
```

## Customize
- Add your CRM extraction code (API/CSV).
- Save final Excel to `outputs/` (ignored by .gitignore).