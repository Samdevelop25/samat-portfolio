# Sales Performance Dashboard (Power BI)

Add your `*.pbix` file here and screenshots in `images/`.

> ⚠️ Use **Git LFS** for `.pbix` files or link to cloud storage if >100MB.