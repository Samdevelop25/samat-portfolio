# Image Classification (CIFAR-10)

**Stack:** TensorFlow/Keras

## Setup
```bash
python -m venv .venv && source .venv/bin/activate
pip install tensorflow pandas numpy matplotlib
```

## Notebook
- Add your training notebook here (avoid committing large models; use LFS).