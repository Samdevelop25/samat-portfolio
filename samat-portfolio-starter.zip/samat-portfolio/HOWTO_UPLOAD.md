# HOW TO UPLOAD TO GITHUB (Quick Guide)

## Option A — Web UI (no command line)
1) Go to https://github.com/new and create a repo named **samat-portfolio** (Public).  
2) On your computer, unzip `samat-portfolio-starter.zip`. Open the `samat-portfolio/` folder.  
3) Drag & drop the entire folder contents into GitHub (Click **Add file → Upload files**). Commit.  
4) For large files (.pbix/.twbx), enable **Git LFS** first (Settings → Code and automation → Git LFS). Then upload.

## Option B — Command Line (recommended)
```bash
# 1) Authenticate (choose one)
# HTTPS (Personal Access Token recommended)
#   Create a PAT at https://github.com/settings/tokens (classic or fine-grained with repo scope).
# SSH
#   ssh-keygen -t ed25519 -C "your_email@example.com"
#   ssh-add ~/.ssh/id_ed25519 && copy ~/.ssh/id_ed25519.pub to https://github.com/settings/keys

# 2) Create repo on GitHub named samat-portfolio (Public)

# 3) In terminal, inside the unzipped folder:
cd samat-portfolio
git init -b main
git lfs install
git add .
git commit -m "Initial portfolio commit"

# 4) Add remote and push
# HTTPS:
git remote add origin https://github.com/logighab/samat-portfolio.git
# SSH:
# git remote add origin git@github.com:logighab/samat-portfolio.git

git push -u origin main
```

## Profile README (shows on your GitHub profile)
1) Create a new repo named exactly **logighab** (Public).  
2) Add a `README.md` (use the provided `PROFILE_README.md` content).  
3) Pin your top repos (Settings → Repositories → Pin).

## Tips
- Keep secrets out of code.  
- Use issues/projects for a public roadmap.  
- Add screenshots/gifs to each project README.  
- Add a LICENSE (MIT included here).  
- For Power BI `.pbix` files >100MB, consider Git LFS or link to cloud storage, and include exported images in README.
