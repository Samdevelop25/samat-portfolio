# Samat Zholdassov
Sunnyvale, CA · samat.email@example.com · (XXX) XXX-XXXX · GitHub: https://github.com/logighab · LinkedIn: https://linkedin.com/in/samat-zholdassov

## SUMMARY
Results-driven Data & Business Analyst with 7+ years of experience in analytics, BI, and data engineering. Skilled in **Python, SQL (BigQuery, Postgres, MySQL), Tableau, Power BI, and Excel (Advanced)** with strong **market & sales research** background. MBA graduate with proven success at **Google** and **Home Credit Bank**. Seeking to leverage Python, SQL, and BI expertise to deliver business impact.

## CORE SKILLS
- **Programming & Data:** Python (Pandas, NumPy, Matplotlib, scikit-learn), SQL (BigQuery, Postgres, MySQL)
- **Visualization & BI:** Tableau, Power BI, Looker Studio
- **Cloud & Tools:** GCP (BigQuery, PLX dashboards), Git/GitHub
- **Analytics:** Market research, sales forecasting, segmentation, A/B testing
- **Excel (Advanced):** Pivot tables, XLOOKUP, Power Query, dashboards

## EXPERIENCE
**Google via Artech LLC – Data Analyst (Contract)** · Sunnyvale, CA · Jul 2022 – Nov 2022  
- Supported **Network Device Inventory / Power & Cooling** by designing Python + **BigQuery** pipelines.  
- Built automated dashboards in **Looker Studio & PLX** for device uptime, cooling efficiency, and compliance.  
- Drove data quality validation and discrepancy resolution across multiple systems.  
- Presented insights influencing capacity planning and cost optimizations.

**Home Credit Bank – Data Analyst** · Astana, Kazakhstan · 2013 – 2019  
- Developed Python automation for fraud detection and credit scoring.  
- Created **Tableau & Excel** dashboards for loan performance and risk monitoring.  
- Conducted **market & sales research** to support product launches and acquisition strategies.  
- Optimized SQL data integration workflows, reducing report TAT by 40%.

## EDUCATION
**California Lincoln University** – MBA, Business Analytics & Management (2019–2022)  
**Eurasian National University** – B.S. in Computer Science

## PROJECTS (see repo folders)
- **Sentiment Analysis App (Python, NLP, Tableau)** – NLP pipeline using NLTK/sklearn; Tableau insights.  
- **Automated Sales Reporting (Python, SQL, Excel)** – ETL from CRM → cleaned in Python → Excel dashboards.  
- **Market Research Dashboard (Tableau/Power BI)** – KPIs for competitor analysis, CAC/CLV, segmentation.  
- **Image Classification (TensorFlow/Keras)** – CIFAR-10 CNN with augmentation & regularization.  
- **Sales Performance Dashboard (Power BI)** – KPIs vs target, regional YOY trends.
