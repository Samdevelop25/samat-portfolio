# Market Research Dashboard

Executive KPI dashboard for competitor analysis, CAC/CLV, and segmentation.

## Files
- Add your `.twbx` (Tableau) or `.pbix` (Power BI) here.
- Include exported PNGs in `images/` for quick viewing.

## Notes
If files exceed 100MB, use **Git LFS** or link to cloud storage.