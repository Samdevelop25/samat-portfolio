# 📊 Samat Zholdassov – Data & Business Analyst Portfolio

Welcome! This portfolio showcases real-world projects in **Python, SQL, Tableau, Power BI, and Market/Sales Research**.

## 🔹 Featured Projects
- **Sentiment Analysis App** → Python NLP, Tableau viz (`sentiment-analysis/`)
- **Market Research Dashboard** → Tableau/Power BI competitor analysis (`market-research-dashboard/`)
- **Automated Sales Reporting** → Python + Excel automation (`sales-automation/`)
- **Image Classification (CIFAR-10)** → TensorFlow/Keras (`image-classification/`)
- **Sales Performance Dashboard** → Power BI visualization (`sales-performance-powerbi/`)

## 🚀 How to use this repo
Each project folder contains a README with setup steps. Large binary files (e.g., `.pbix`, `.twbx`) should use **Git LFS**.

## 🔗 Links
- LinkedIn: https://linkedin.com/in/samat-zholdassov
- GitHub Profile: https://github.com/logighab
